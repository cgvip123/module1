package com.cg_vip.lab11;
import java.util.List;
import java.util.stream.Collectors;

import com.cg_vip.employeeDepartment.beans.Employee;
import com.cg_vip.employeeRepository.repo.EmployeeRepository;

public class Main {

	public static void main(String[] args) {
		// Find out department without employees
		List<Employee> emplist = EmployeeRepository.list;
		
		
		List<Employee> elist = emplist.stream().filter(emp -> emp.getDepartment()!=null).collect(Collectors.toList());
		
	}

}
