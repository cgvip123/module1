package com.cg_vip.lab10;
import java.util.List;
import java.util.stream.Collectors;

import com.cg_vip.employeeDepartment.beans.*;
import com.cg_vip.employeeRepository.repo.*;

public class Main {

	public static void main(String[] args) {
		
		List<Employee> list = EmployeeRepository.list;
		
		// Find out employees without department.
		
		List<Employee> l = list.stream().filter(emp -> emp.getDepartment()==null).collect(Collectors.toList());
		
		l.forEach(emp -> System.out.println(emp));
	}

}
