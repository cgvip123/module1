package com.cg_vip.lab3;
interface Authentication {
	String userName = "Vipul";
	int password = 781581;
	
	boolean authentication(String userName, int password);
}
public class Main {

	public static void main(String[] args) {
		
		Authentication auth = (String userName, int password) -> {
			
			if(userName.equals(Authentication.userName) && password == Authentication.password)	return true;
			
			return false;
		};

		System.out.println(auth.authentication("Vipul", 12345));
		
		System.out.println(auth.authentication("Thakur", 12345));
		
	}

}
