package com.cg_vip.employeeRepository.repo;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.cg_vip.employeeDepartment.beans.Department;
import com.cg_vip.employeeDepartment.beans.Employee;

public class EmployeeRepository {

	public static List<Employee> list = new ArrayList<>();
	
	static {
		//Department department = new Department(departmentId, departmentName, managerId);
		//Employee employee = new Employee(employeeId, firstName, lastName, email, phoneNumber, hireDate, designation, salary, managerId, department)
		
		Department hr = new Department(100, "HR", 1);
		Department finance = new Department(101, "Finance", 2);
		Department cs = new Department(102, "CS", 3);
		
		LocalDate ld = LocalDate.now().of(1997, 04, 12);
		list.add(new Employee(1001, "Vipul", "Thakur", "vipulthakur.thakur@gmail.com", "8484541544", ld, "Manager", 485154, 1, cs));
		ld = LocalDate.now().of(1958, 05, 12);
		list.add(new Employee(1002, "Rahul Chauhan", "chauhan", "rahul.chauhan_cs@asn.com", "4415451854", ld, "HR", 48484845, 1, null));
		ld = LocalDate.now().of(2001, 12, 20);
		list.add(new Employee(1003, "SHUBHAM", "SHARMA", "shubham.sharma@gmail.com", "7060285628", ld, "MANAGER", 1000000, 3, cs));
		ld = LocalDate.now().of(1999, 12, 31);
		list.add(new Employee(1004, "RAHUL", "SHARMA", "rahul.sharma@gmail.com", "7584965821", ld, "HR", 5000000, 2, finance));

	}
	
}
