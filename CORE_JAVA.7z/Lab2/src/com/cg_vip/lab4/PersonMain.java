package com.cg_vip.lab4;
public class PersonMain
{
	public static void main(String args[])
	{
		Person p1 = new Person();
		Person p2 = new Person("Divya","Bharti",'F',"8787878778");
		Person p3 = new Person("kavya","Bharti",'F',"9797979779");
		System.out.println(p3);
	}
}

