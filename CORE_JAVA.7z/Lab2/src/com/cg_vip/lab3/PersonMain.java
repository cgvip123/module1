package com.cg_vip.lab3;

public class PersonMain
{
	public static void main(String args[])
	{
		Person p1 = new Person();
		//Person p2 = new Person("Divya","Bharti",'F');
		System.out.println(p1);
	}
}
