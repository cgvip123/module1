package com.cg_vip.lab5;

public enum Gender {
	M,F
}
