package com.cg_vip.lab5;

public class PersonMain 
{
	public static void main(String args[])
	{
		Person p1 = new Person();
		Person p2 = new Person("Divya","Bharti",Gender.F,"8787878778");
		Person p3 = new Person("kavya","Bharti",Gender.F,"9797979779");
		System.out.println(p2);
	}

	

}
