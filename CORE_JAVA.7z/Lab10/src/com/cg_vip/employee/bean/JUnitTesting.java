package com.cg_vip.employee.bean;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class JUnitTesting {

	@Test
	public void unSuccessfullTest() {
		ExceptionCheck ec = new ExceptionCheck();
		
		assertEquals("Exception Handled", ec.checking(101, "Vipul", 2014));
	}
	
	@Test
	public void successfullTest() {
		ExceptionCheck ec = new ExceptionCheck();
		
		assertEquals(null, ec.checking(101, "Vipul", 8748425));
	}

}
