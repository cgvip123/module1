package com.cg_vip.employee.bean;

public class ExceptionCheck extends Exception {
	
	public String checking(int id, String name, double salary) {
		Service s = new Service();
		try {
			System.out.println(s.creatEmployee(id, name, salary));
		} catch (EmployeeException e) {
			return "Exception ";
		}
		return null;
	}
}
