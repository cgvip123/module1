package com.cg_vip.employee.bean;

public class EmployeeException extends Exception{

}
