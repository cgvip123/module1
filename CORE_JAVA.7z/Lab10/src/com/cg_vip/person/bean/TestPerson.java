package com.cg_vip.person.bean;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
public class TestPerson {

	enum GENDER{M, F};
	
	@Test
	public void checkingForFirstName() {
		Person person = new Person();
		person.setFirstName("VIPUL");
		assertEquals("VIPUL", person.getFirstName());
	}
	@Test
	public void checkingForLastName() {
		Person person = new Person();
		person.setLastName("THAKUR");
		assertEquals("THAKUR", person.getLastName());
	}
	@Test
	public void checkingForGender() {
		Person person = new Person();
		person.setGender('M');
		assertEquals(com.cg_vip.person.bean.Person.GENDER.M, person.getGender());
	}
	@Test
	public void checkingForPhoneNumber() {
		Person person = new Person();
		person.setPhoneNumber("7894546123");
		assertEquals("9876543214", person.getPhoneNumber());
	}
	
}