package com.cg_vip.lab2;

public class PersonMain {

	public static void main(String[] args) throws MyException
	{
			Person p1 = new Person("Bharti","Vidya", 'F',16);
			

	}

}
