package com.cg_vip.lab2;

public class MyException extends Exception 
{
	public MyException(String s) 
	{
		super(s);
	}
	
}
