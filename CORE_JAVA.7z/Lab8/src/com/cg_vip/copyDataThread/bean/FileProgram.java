package com.cg_vip.copyDataThread.bean;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class FileProgram {
	public static void main(String[] args) {
		
		CopyDataThread s=null;
     try {
		 s=new CopyDataThread(new FileReader("C:\\Users\\VIPUTHAK\\Documents\\Vipul Thakur\\input.txt"),new FileWriter("C:\\Users\\VIPUTHAK\\Documents\\Vipul Thakur\\output.txt"));
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
     s.start();
}
}