package com.cg_vip.copyDataThread.bean;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class CopyDataThread extends Thread {
FileReader input=null;
FileWriter output=null;
public CopyDataThread(FileReader input, FileWriter output) {
	super();
	this.input = input;
	this.output = output;
}
public void run() 
{
int i=0,j=0;
try {
	while((i=input.read())!=-1)
	{output.write((char)i);j++;
	System.out.print((char)i);
	if(j%10==0)
	{
	System.out.println(" characters copied 10");
	Thread.sleep(5000);
	}
	}
	System.out.println("Completed");
} catch (IOException | InterruptedException e) {

	e.printStackTrace();
}
}
}